# face_&_person > 2025-01-06 9:14am
https://universe.roboflow.com/personal-z22ho/face_-_person

Provided by a Roboflow user
License: undefined

